# Logbook - Backend
# Work in progress - The project is in early stage.

This project is a part of a bigger project - An online application that is targeted for people related with aviation.

## The purpose
The application purpose is to replace paper version of logbook. The main functions consist of storing and processing the data that is required by EASA Part FCL.
