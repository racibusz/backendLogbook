export interface RegisterDTO{
    password: string,
    email: string,
}