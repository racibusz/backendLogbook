export const jwtConstants = {
    secret: 'XD'
}
// This secret will be changed in production.