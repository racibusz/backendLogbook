export interface SignInDTO {
    email: string;
    password: string;
}